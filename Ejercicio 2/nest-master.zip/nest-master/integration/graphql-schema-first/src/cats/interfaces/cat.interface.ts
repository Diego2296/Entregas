export interface Cat {
  readonly id: number;
  readonly name: string;
  readonly age: number;
}
